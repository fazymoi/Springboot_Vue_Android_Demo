package com.example.vuetest.pojo;

import java.io.Serializable;

public class LinkKey implements Serializable {
    int userid;
    int storeid;

}
