package com.example.vuetest.controller;

import com.example.vuetest.pojo.User;
import com.example.vuetest.result.Result;
import com.example.vuetest.result.ResultFactory;
import com.example.vuetest.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;

import java.util.concurrent.atomic.AtomicInteger;

@Controller
public class LoginController {

    @Autowired
    UserService userService;

    @CrossOrigin
    @PostMapping(value = "/api/login")
    @ResponseBody
    //requestbody only for post
    public Result login(@RequestBody User requestUser,HttpSession session) {
        String username = requestUser.getUsername();
//        System.out.println(username);
        username = HtmlUtils.htmlEscape(username);//html特殊字符转译
        String password = requestUser.getPassword();
        System.out.println("!!!login!!!");
        System.out.println(username+password);
        User user = userService.get(username, password);


//        String username1= (String) session.getAttribute("username");
//        System.out.println(username1);
//        AtomicInteger userCount = listener.userCount;
//        System.out.println(userCount);
        if (null == user) {
            return ResultFactory.buildFailResult("密码错误");
        } else {
            int userid=user.getId();
            System.out.println("!"+userid);
            session.setAttribute("userid", userid);
            System.out.println(session.getId());
            return ResultFactory.buildSuccessResult(null);
        }
    }

    @CrossOrigin
    @PostMapping("/api/register")
    @ResponseBody
    public Result register(@RequestBody User user) {
        int status = userService.register(user);
        System.out.println("!!!register!!!");
        switch (status) {
            case 0:
                return ResultFactory.buildFailResult("用户名和密码不能为空");
            case 1:
                return ResultFactory.buildSuccessResult("注册成功");
            case 2:
                return ResultFactory.buildFailResult("用户已存在");
        }
        return ResultFactory.buildFailResult("未知错误");
    }

    @CrossOrigin
    @PostMapping("/api/index")
    @ResponseBody
    public Result index(@RequestBody User user,HttpSession session) {
        int userid= (int) session.getAttribute("userid");
        System.out.println(userid);
        return ResultFactory.buildSuccessResult(userid);
    }
}
