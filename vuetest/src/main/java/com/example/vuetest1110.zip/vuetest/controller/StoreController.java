package com.example.vuetest.controller;

import com.example.vuetest.pojo.Link;
import com.example.vuetest.pojo.Store;
import com.example.vuetest.pojo.User;
import com.example.vuetest.result.Result;
import com.example.vuetest.result.ResultFactory;
import com.example.vuetest.service.LinkService;
import com.example.vuetest.service.StoreService;
import com.example.vuetest.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.List;

@Controller
public class StoreController {

    @Autowired
    StoreService storeService;
    @Autowired
    LinkService linkService;

    @CrossOrigin
    @PostMapping("/api/mystore")
    @ResponseBody
    public List<Store> list(@RequestBody User user,HttpSession session){
        System.out.println("!!!mystore!!!");
        System.out.println(session.getId());
        int userid= (int) session.getAttribute("userid");
        System.out.println(linkService.link_mystore(userid));
        int storeid;
        Store temp;
        List<Link> mystorelist=linkService.link_mystore(userid);
        List<Store> mystore = new ArrayList<Store>();
        for (int i = 0; i < mystorelist.size(); i++) {
            Link l = mystorelist.get(i);
            storeid=l.getStoreid();
            System.out.println(storeid);
            temp = storeService.findByStoreid(storeid);
            mystore.add(temp);
        }
        return mystore;
    }

    @CrossOrigin
    @PostMapping("/api/addstore")
    @ResponseBody
    public Result addstore(@RequestBody Store store,HttpSession session){
        System.out.println("!!!addstore!!!");
        System.out.println(session.getId());
        System.out.println(store.getStatus());
        System.out.println(store.getIntroduction());
        int userid= (int) session.getAttribute("userid");
        if  (storeService.isStorenameExist((store.getStorename()))==true)
            return ResultFactory.buildFailResult("已有同名商家");
        else if(storeService.isStorecodeExist((store.getStorecode()))==true)
            return ResultFactory.buildFailResult("商家已存在");
        else {
            int storeid = storeService.AddStore(store);
            System.out.println(storeid+userid);
            Link link = new Link(userid,storeid);
            linkService.Addlink(link);
            return ResultFactory.buildResult(200,"添加成功",null);
        }
    }
    @CrossOrigin
    @PostMapping("/api/deletestore")
    @ResponseBody
    public Result deletestore(@RequestBody Store store,HttpSession session){
        System.out.println("!!!deletestore!!!");
        System.out.println(session.getId());
        int userid= (int) session.getAttribute("userid");
        linkService.deleteByStoreid(store.getStoreid());
        storeService.deleteByStoreid(store.getStoreid());
        return ResultFactory.buildResult(200,"删除成功",null);
    }
    @CrossOrigin
    @PostMapping("/api/updatestore")
    @ResponseBody
    public Result updatestore(@RequestBody Store store,HttpSession session){
        System.out.println("!!!updatestore!!!");
        System.out.println(session.getId());
        int userid= (int) session.getAttribute("userid");
        System.out.println(store.getStoreid());
        System.out.println(storeService.getsameStorenameStoreid((store.getStorename())));

        if  (storeService.isStorenameExist((store.getStorename()))==true &&
                store.getStoreid() != storeService.getsameStorenameStoreid((store.getStorename())))
        {
                return ResultFactory.buildFailResult("已有同名商家");
        }
        else if(storeService.isStorecodeExist((store.getStorecode()))==true &&
                store.getStoreid() != storeService.getsameStorecodeStoreid((store.getStorecode())))
            return ResultFactory.buildFailResult("商家已存在");
        else {
            storeService.UpdateStore(store);
            return ResultFactory.buildResult(200,"修改成功",null);
        }
    }
}
