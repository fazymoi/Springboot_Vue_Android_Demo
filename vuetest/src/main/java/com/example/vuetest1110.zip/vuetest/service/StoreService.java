package com.example.vuetest.service;
import com.example.vuetest.dao.StoreDAO;
import com.example.vuetest.dao.UserDAO;
import com.example.vuetest.pojo.User;
import com.example.vuetest.pojo.Store;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.List;
@Service
public class StoreService {
    @Autowired
    StoreDAO storeDAO;
    public Store findByStoreid(int storeid) {
        return storeDAO.findByStoreidIs(storeid);
    }
    public boolean isStorenameExist(String Storename) {
        Store store = storeDAO.findByStorenameIs(Storename);
        return null!=store;
    }
    public void UpdateStore(Store store) {
        System.out.println(store.getStorename());
        Store storenew = storeDAO.findByStoreidIs(store.getStoreid());
        storenew.setContact(store.getContact());
        storenew.setIntroduction(store.getIntroduction());
        storenew.setOpeninghours(store.getOpeninghours());
        storenew.setStoreaddr(store.getStoreaddr());
        storenew.setStorecode(store.getStorecode());
        storenew.setStatus(store.getStatus());
        storenew.setStorename(store.getStorename());
        storeDAO.save(storenew);
    }

    public int AddStore(Store store) {

        storeDAO.save(store);
        return store.getStoreid();

    }

    public void deleteByStoreid(int id) {
        storeDAO.deleteByStoreid(id);
    }


    public boolean isStorecodeExist(String storecode) {
        Store store = storeDAO.findByStorecodeIs(storecode);
        return null!=store;
    }

    public int getsameStorecodeStoreid(String storecode) {
        Store store = storeDAO.findByStorecodeIs(storecode);
        return store.getStoreid();
    }

    public int getsameStorenameStoreid(String storename) {
        Store store = storeDAO.findByStorenameIs(storename);
        return store.getStoreid();
    }

}
