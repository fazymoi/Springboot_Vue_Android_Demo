package com.example.vuetest.dao;

import com.example.vuetest.pojo.Store;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import java.util.List;

public interface StoreDAO extends JpaRepository<Store,Integer> {
    Sort sort = null;

    Store findByStorenameIs(String storename);
    Store findByStorecodeIs(String storecode);
    @Modifying
    @Transactional
    void deleteByStoreid(int id);

    Store findByStoreidIs(int storeid);

}
