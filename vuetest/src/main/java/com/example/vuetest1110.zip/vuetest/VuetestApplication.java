package com.example.vuetest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VuetestApplication {

    public static void main(String[] args) {
        SpringApplication.run(VuetestApplication.class, args);
    }

}
